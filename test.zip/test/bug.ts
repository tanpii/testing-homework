export const bug = ''
//'?bug_id=6'